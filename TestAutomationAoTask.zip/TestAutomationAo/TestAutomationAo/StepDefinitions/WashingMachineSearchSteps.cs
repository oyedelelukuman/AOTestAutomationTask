﻿using TechTalk.SpecFlow;
using TestAutomationAo.SetUps;
using TestAutomationAo.Pages;
using NUnit.Framework;
using System.Threading;

namespace TestAutomationAo.StepDefinition
{
    [Binding]
    public class WashingMachineSearchSteps
    {

        Context _context;
        WashingMachineSearchPage _washingMachineSearch;



        public WashingMachineSearchSteps(Context context, WashingMachineSearchPage washingMachineSearch)
        {
            _context = context;
            _washingMachineSearch = washingMachineSearch;

        }

        [Given(@"I navigate to the AO Website")]
        public void GivenINavigateToTheAOWebsite()
        {
            _context.LoadAOWebsiteApplication();
        }

        [Given(@"I search for '(.*)'")]
        public void GivenISearchFor(string searchItemText)
        {

            _washingMachineSearch.CloseAlertPopUp();
            _washingMachineSearch.EnterSearchItem(searchItemText);
            _washingMachineSearch.ClickOnsearch();
        }

        [Given(@"I select a '(.*)'")]
        public void GivenISelectA(string BrandType)
        {
            _washingMachineSearch.SelectBrandType(BrandType);
        }

        [When(@"I select '(.*)' from the left filter sidebar")]
        public void WhenISelectFromTheLeftFilterSidebar(string searchCriteria)
        {
            _washingMachineSearch.ClickOnMoreFilterOption();
            _washingMachineSearch.SelectAFilterOption(searchCriteria);
        }

        [Then(@"I will validate the page title matches the '(.*)'")]
        public void ThenIWillValidateThePageTitleMatchesThe(string expectedSearchPageTitle)
        {
       
            Assert.That(_washingMachineSearch.PageHeaderOneText(), Does.Contain(expectedSearchPageTitle));
        }

        [AfterScenario]
       
        public void ShutdownApplication()
        {
            _context.ShutDownAOWebsiteApplication();
        }
    }
}
