﻿using OpenQA.Selenium;

namespace TestAutomationAo.Pages
{
    public class WashingMachineSearchPage
    {
        private IWebDriver _driver;

        public WashingMachineSearchPage(IWebDriver driver)
        {
            _driver = driver;
        }
        By searchItemTextField = By.CssSelector("#siteSearch-input");
        By selectedSearchCriteria = By.XPath("//*[@id='style-1']/div[6]/div[2]/fieldset/div[3]/a/label");
        By searchButton = By.CssSelector("span.ico.ico-search.leading-none.static");
        By popup = By.CssSelector("button.promotionModalClose.icon-close.c-modal-close.u-pos--absolute.ico.ico-close.ico-lg");
        By moreOption = By.CssSelector("button.cta.cta-secondary.text-center.text-sm.w-full.px-2");
        By headerOneText = By.XPath("//h1");
        By footercookies = By.CssSelector("button.ao-cb__button.ao-cb__button--decline.cta.cta-secondary");
        By headercookies = By.Id("acceptMessage");
        public void CloseAlertPopUp()
        {
            if (_driver.FindElement(popup) != null)
            { 
                _driver.FindElement(popup).Click();
                _driver.FindElement(headercookies).Click(); 
            }

           else if (_driver.FindElement(footercookies) != null)
            {
                _driver.FindElement(footercookies).Click();
                _driver.FindElement(headercookies).Click();
            }
            else if ((_driver.FindElement(popup) != null) && (_driver.FindElement(footercookies) != null))
            {
                _driver.FindElement(popup).Click();
                _driver.FindElement(headercookies).Click();
                _driver.FindElement(footercookies).Click();
            }
            else
            {
                _driver.FindElement(headercookies).Click();
            }
        }
   
        public void EnterSearchItem(string searchItemText)
        {
            _driver.FindElement(searchItemTextField).Clear();
            _driver.FindElement(searchItemTextField).SendKeys(searchItemText);
        }
        public void ClickOnsearch()
        {
            _driver.FindElement(searchButton).Click();
        }
        public void ClickOnMoreFilterOption()
        {
            _driver.FindElement(moreOption).Click();
       
        }
        public void SelectBrandType(string BrandType)
        {
            By brandType = By.CssSelector("a.brandSprite.brandSprite_" + BrandType);
            _driver.FindElement(brandType).Click();
        }
        public void SelectAFilterOption(string searchCriteria)
        {
            if (searchCriteria == "A++ & above")
                {
                By selectedSearchCriteria = By.XPath("//*[@id='style-1']/div[7]/div[2]/fieldset/div[3]/a/label");
                _driver.FindElement(selectedSearchCriteria).Click();
            }
            else if (searchCriteria == "Large")
            {
                By selectedSearchCriteria = By.XPath("//*[@id='style-1']/div[3]/div[2]/fieldset/div[1]/a/label/span/span[2]/span[1]");
                _driver.FindElement(selectedSearchCriteria).Click();
            }
            else if (searchCriteria == " Silver  colour")
            {
                By selectedSearchCriteria = By.XPath("//*[@id='style-1']/div[4]/div[2]/fieldset/div/div/div[2]/a/label/div[1]");
                _driver.FindElement(selectedSearchCriteria).Click();
            }
            else 
            {
                _driver.FindElement(selectedSearchCriteria).Click();
            }
            
        }
        public string PageHeaderOneText()
        {
            return _driver.FindElement(headerOneText).Text;
        }
        
    }
}