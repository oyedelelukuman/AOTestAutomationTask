﻿using BoDi;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;


namespace TestAutomationAo.SetUps
{
    public class Context
    {

        public IObjectContainer _objectContainer;
        private IWebDriver _driver;
        private String baseUrl = "https://ao.com/";


        public Context(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
            _driver = new ChromeDriver();
            _objectContainer.RegisterInstanceAs<IWebDriver>(_driver);
        }

        public void LoadAOWebsiteApplication()
        {
            _driver.Manage().Cookies.DeleteAllCookies();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
            _driver.Navigate().GoToUrl(baseUrl);
            _driver.Manage().Window.Maximize();
            _driver.Manage().Cookies.DeleteAllCookies();
        }

        public void ShutDownAOWebsiteApplication()
        {
            _driver.Quit();
            _driver.Dispose();
        }


    }
}
